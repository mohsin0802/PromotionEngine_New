﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Items For Product A: ");
            int itemA = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Items For Product B: ");
            int itemB = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Items For Product C: ");
            int itemC = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Items For Product D: ");
            int itemD = Convert.ToInt32(Console.ReadLine());
            int total = Result(itemA, itemB, itemC, itemD);
            Console.WriteLine("Total : " + total);
            Console.ReadLine();
        }
        public static int Result(int itemA, int itemB, int itemC, int itemD)
        {
            int total = 0, div=0,rem=0;
            
            if (itemA != 0 && itemA >=3)
            {
                div = itemA / 3;
                rem = itemA % 3;
                total = total + (div * 130) + (rem * 50);
            }
            else
            {
                rem = itemA % 3;
                total = (rem * 50);
            }
            if(itemB != 0 && itemB >= 2)
            {
                div = itemB / 2;
                rem = itemB % 2;
                total = total + (div * 45) + (rem * 30);
            }
            else
            {
                rem = itemB % 2;
                total = (rem * 30);
            }
            if (itemC != 0 && itemD != 0)
            {
                total = total + 30;
            }
            else if(itemC != 0 && itemD == 0)
            {
                total = total + 20;
            }
            else if (itemC == 0 && itemD != 0)
            {
                total = total + 15;
            }
            return total;
        }
    }
}
